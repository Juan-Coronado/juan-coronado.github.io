using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Identity;
namespace Metropolitano;
public sealed class Usuario {
    public string Id {get;set;}=Guid.NewGuid().ToString("N");
    public string Dni {get;set;}="";
    public string Nombres {get;set;}="";
    public string Apellidos {get;set;}="";
    public string Telefono {get;set;}="";
    public string Hash {get;set;}="";
    public Tarjeta? Tarjeta {get;set;}
}
public sealed class Tarjeta {
    public string Codigo {get;set;}=Guid.NewGuid().ToString("N")[..12].ToUpperInvariant();
    public string Tipo {get;set;}="Normal";
    public decimal Saldo {get;set;}
    public DateTime Vence {get;set;}=DateTime.UtcNow.AddYears(5);
    public bool Robada {get;set;}
}
public sealed class Store {
    private readonly object gate=new();
    private readonly string file;
    private readonly PasswordHasher<Usuario> hasher=new();
    public static readonly string[] Tipos={"Normal","Universitaria","Discapacitados"};
    public Store(IWebHostEnvironment environment){
        var directory=Path.Combine(environment.ContentRootPath,"App_Data");Directory.CreateDirectory(directory);
        file=Path.Combine(directory,"usuarios.json");
    }
    private List<Usuario> Read()=>File.Exists(file)?JsonSerializer.Deserialize<List<Usuario>>(File.ReadAllText(file))??throw new IOException("Archivo de usuarios vacio"):new();
    private void Save(List<Usuario> usuarios){
        var temporary=file+".tmp";
        try {File.WriteAllText(temporary,JsonSerializer.Serialize(usuarios));File.Move(temporary,file,true);}
        finally {if(File.Exists(temporary))File.Delete(temporary);}
    }
    public Usuario Registrar(string dni,string nombres,string apellidos,string telefono,string password){
        if(!Regex.IsMatch(dni,"^[0-9]{8}$") || string.IsNullOrWhiteSpace(nombres) || string.IsNullOrWhiteSpace(apellidos) || nombres.Length>80 || apellidos.Length>80 || telefono.Length>20 || password.Length<8 || password.Length>128)
            throw new ArgumentException("Usa DNI de 8 digitos, nombres completos y una clave de 8 a 128 caracteres.");
        lock(gate){
            var list=Read();if(list.Any(u=>u.Dni==dni))throw new ArgumentException("No se pudo registrar ese DNI. Prueba iniciar sesion.");
            var user=new Usuario{Dni=dni,Nombres=nombres.Trim(),Apellidos=apellidos.Trim(),Telefono=telefono.Trim()};
            user.Hash=hasher.HashPassword(user,password);list.Add(user);Save(list);return user;
        }
    }
    public Usuario? Login(string dni,string password){lock(gate){var user=Read().FirstOrDefault(u=>u.Dni==dni);return user!=null && hasher.VerifyHashedPassword(user,user.Hash,password)!=PasswordVerificationResult.Failed?user:null;}}
    public Usuario Obtener(string id){lock(gate){return Read().FirstOrDefault(u=>u.Id==id)??throw new ArgumentException("La sesion no corresponde a un usuario.");}}
    public void Cambiar(string id,Action<Usuario> mutation){lock(gate){var list=Read();var user=list.FirstOrDefault(u=>u.Id==id)??throw new ArgumentException("Usuario no encontrado");mutation(user);Save(list);}}
    public void Solicitar(string id,string tipo){
        if(!Tipos.Contains(tipo))throw new ArgumentException("Selecciona un tipo de tarjeta valido.");
        Cambiar(id,u=>{if(u.Tarjeta!=null)throw new ArgumentException("Ya tienes una tarjeta asignada.");u.Tarjeta=new Tarjeta{Tipo=tipo};});
    }
    public void Recargar(string id,decimal monto){
        if(monto<=0 || monto>1000 || decimal.Round(monto,2)!=monto)throw new ArgumentException("El monto debe estar entre S/0.01 y S/1000, con maximo dos decimales.");
        Cambiar(id,u=>{var t=u.Tarjeta??throw new ArgumentException("Solicita una tarjeta primero.");if(t.Robada || t.Vence<DateTime.UtcNow)throw new ArgumentException("La tarjeta esta bloqueada o vencida.");t.Saldo=checked(t.Saldo+monto);});
    }
    public void Reportar(string id,string motivo){
        if(string.IsNullOrWhiteSpace(motivo) || motivo.Length>500)throw new ArgumentException("Escribe un motivo de hasta 500 caracteres.");
        Cambiar(id,u=>{var t=u.Tarjeta??throw new ArgumentException("No tienes tarjeta.");t.Robada=true;});
    }
}
