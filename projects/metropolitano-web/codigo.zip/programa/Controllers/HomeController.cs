using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
namespace Metropolitano.Controllers;
[Authorize]
public sealed class HomeController:Controller {
    private readonly Store store;
    public HomeController(Store store){this.store=store;}
    private string Id=>User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    [AllowAnonymous] public IActionResult Index()=>User.Identity?.IsAuthenticated==true?RedirectToAction("Dashboard"):RedirectToAction("Login","Acceso");
    public IActionResult Dashboard()=>View(store.Obtener(Id));
    private IActionResult Operar(Action action){
        try {action();TempData["Mensaje"]="Operacion realizada en esta demostracion.";}
        catch(ArgumentException ex){TempData["Error"]=ex.Message;}
        catch(IOException){TempData["Error"]="No se pudo guardar el cambio. Intenta de nuevo.";}
        return RedirectToAction("Dashboard");
    }
    [HttpPost] public IActionResult Solicitar(string tipo="")=>Operar(()=>store.Solicitar(Id,tipo));
    [HttpPost] public IActionResult Recargar(decimal monto)=>!ModelState.IsValid?Operar(()=>throw new ArgumentException("Monto no valido")):Operar(()=>store.Recargar(Id,monto));
    [HttpPost] public IActionResult Reportar(string motivo="")=>Operar(()=>store.Reportar(Id,motivo));
}
