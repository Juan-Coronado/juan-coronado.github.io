using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
namespace Metropolitano.Controllers;
public sealed class AccesoController:Controller {
    private readonly Store store;
    public AccesoController(Store store){this.store=store;}
    [HttpGet] public IActionResult Login()=>View("Acceso");
    [HttpGet] public IActionResult Registrar(){ViewBag.Registro=true;return View("Acceso");}
    private async Task Entrar(Usuario u)=>await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(new[]{new Claim(ClaimTypes.NameIdentifier,u.Id),new Claim(ClaimTypes.Name,u.Nombres)},CookieAuthenticationDefaults.AuthenticationScheme)));
    [HttpPost] public async Task<IActionResult> Login(string dni="",string password=""){
        var user=store.Login(dni,password);
        if(user==null){ModelState.AddModelError("","DNI o contraseña incorrectos.");return View("Acceso");}
        await Entrar(user);return RedirectToAction("Dashboard","Home");
    }
    [HttpPost] public async Task<IActionResult> Registrar(string dni="",string nombres="",string apellidos="",string telefono="",string password=""){
        try {var user=store.Registrar(dni,nombres,apellidos,telefono,password);await Entrar(user);return RedirectToAction("Dashboard","Home");}
        catch(ArgumentException ex){ModelState.AddModelError("",ex.Message);ViewBag.Registro=true;return View("Acceso");}
        catch(IOException){ModelState.AddModelError("","No se pudo guardar. Tus datos anteriores siguen disponibles.");ViewBag.Registro=true;return View("Acceso");}
    }
    [HttpPost] public async Task<IActionResult> Salir(){await HttpContext.SignOutAsync();return RedirectToAction("Login");}
}
