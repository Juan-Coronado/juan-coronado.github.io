from urllib.request import build_opener, HTTPCookieProcessor, Request
from urllib.parse import urlencode
from urllib.error import HTTPError
from http.cookiejar import CookieJar
from pathlib import Path
import re,secrets,json,html

BASE='http://127.0.0.1:4323'
client=build_opener(HTTPCookieProcessor(CookieJar()))
def get(path):
    return html.unescape(client.open(BASE+path).read().decode('utf-8'))
def token(page):
    return re.search(r'name="__RequestVerificationToken"[^>]*value="([^"]+)"',page)[1]
def post(path,page,fields):
    body=urlencode({**fields,'__RequestVerificationToken':token(page)}).encode()
    return html.unescape(client.open(Request(BASE+path,body)).read().decode('utf-8'))

assert 'Iniciar sesión' in get('/Home/Dashboard')
try:
    client.open(Request(BASE+'/Acceso/Login',b'dni=00000000&password=sin-token'))
    raise AssertionError('Se acepto POST sin antifalsificacion')
except HTTPError as error: assert error.code==400
page=get('/Acceso/Registrar')
dni=f'{secrets.randbelow(100000000):08d}'
password=secrets.token_urlsafe(16)
page=post('/Acceso/Registrar',page,{'dni':dni,'nombres':'Persona','apellidos':'De prueba','telefono':'000000000','password':password})
assert 'Hola, Persona' in page
page=post('/Home/Solicitar',page,{'tipo':'Universitaria'})
assert 'S/ 0.00' in page
page=post('/Home/Recargar',page,{'monto':'12.50'})
assert 'S/ 12.50' in page
page=post('/Home/Recargar',page,{'monto':'-5'})
assert 'S/ 12.50' in page and 'maximo dos decimales' in page
page=post('/Home/Reportar',page,{'motivo':'Reporte de prueba'})
assert 'Bloqueada' in page
page=post('/Home/Recargar',page,{'monto':'5'})
assert 'S/ 12.50' in page and 'bloqueada' in page
page=post('/Acceso/Salir',page,{})
assert 'Iniciar sesión' in page
page=post('/Acceso/Login',page,{'dni':dni,'password':password})
assert 'S/ 12.50' in page and 'Bloqueada' in page
for path in ['/App_Data/usuarios.json','/App_Data/keys/']:
    try: get(path);raise AssertionError('Se expuso App_Data')
    except HTTPError as error:assert error.code==404
root=Path(__file__).resolve().parents[1]
assert password not in (root/'programa/App_Data/usuarios.json').read_text()
output='ASP.NET: registro, autenticacion, CSRF, solicitud, recarga, monto negativo, bloqueo, cierre de sesion y persistencia comprobados. App_Data no es publico; no se guarda la clave en texto plano.\n'
(root/'evidencia').mkdir(exist_ok=True)
(root/'evidencia/pruebas.txt').write_text(output,encoding='utf-8')
print(output)
