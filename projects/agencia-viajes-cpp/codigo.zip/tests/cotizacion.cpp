#include "../programa/catalogo.hpp"
#include <cassert>
int main(){
 assert(cotizar(322,3)==966);
 assert(cotizar(42,365)==15330);
 for(int dias:{0,-1,366}){bool fallo=false;try{cotizar(200,dias);}catch(const std::invalid_argument&){fallo=true;}assert(fallo);}
}
