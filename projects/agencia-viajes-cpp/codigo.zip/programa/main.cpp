#include "catalogo.hpp"
#include <iostream>
#include <sstream>

bool leerEntero(const std::string& mensaje,int minimo,int maximo,int& valor){
    std::string linea;
    while(std::cout<<mensaje && std::getline(std::cin,linea)){
        std::istringstream entrada(linea);char sobrante;
        if(entrada>>valor && !(entrada>>sobrante) && valor>=minimo && valor<=maximo)return true;
        std::cout<<"Entrada no valida. Rango: "<<minimo<<"-"<<maximo<<".\n";
    }
    return false;
}
int main(){
    std::cout<<"AGENCIA DE VIAJES\nTarifas academicas originales de 2022 (PEN).\n";
    int opcion;
    while(leerEntero("\n1. Destinos  2. Hoteles  3. Restaurantes  4. Coches  0. Salir\nOpcion: ",0,4,opcion) && opcion!=0){
        std::string nombre;std::cout<<"Nombre completo: ";
        if(!std::getline(std::cin,nombre))break;
        if(nombre.find_first_not_of(" \t")==std::string::npos){std::cout<<"El nombre es obligatorio.\n";continue;}
        std::string servicio;long long total=0;int elegido;
        if(opcion==1){
            for(size_t i=0;i<regiones.size();++i)std::cout<<i+1<<". "<<regiones[i].nombre<<'\n';
            if(!leerEntero("Region: ",1,static_cast<int>(regiones.size()),elegido))break;
            const auto& region=regiones[elegido-1];
            for(size_t i=0;i<region.paises.size();++i)std::cout<<i+1<<". "<<region.paises[i]<<'\n';
            if(!leerEntero("Pais: ",1,static_cast<int>(region.paises.size()),elegido))break;
            servicio="Vuelo a "+region.paises[elegido-1];total=region.soles;
        }else{
            const auto& lista=opcion==2?hoteles:opcion==3?restaurantes:coches;
            for(size_t i=0;i<lista.size();++i)std::cout<<i+1<<". "<<lista[i].nombre<<" - S/ "<<lista[i].soles<<" por dia\n";
            if(!leerEntero("Servicio: ",1,static_cast<int>(lista.size()),elegido))break;
            int dias;if(!leerEntero("Dias (1-365): ",1,365,dias))break;
            servicio=lista[elegido-1].nombre+" / "+std::to_string(dias)+" dias";total=cotizar(lista[elegido-1].soles,dias);
        }
        std::cout<<"\nCOTIZACION\nCliente: "<<nombre<<"\nServicio: "<<servicio<<"\nTotal: S/ "<<total<<".00\n";
    }
    std::cout<<"\nSesion finalizada.\n";
}
