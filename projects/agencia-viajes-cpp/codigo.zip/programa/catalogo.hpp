#pragma once
#include <stdexcept>
#include <string>
#include <vector>
struct Servicio { std::string nombre; long long soles; };
struct Region { std::string nombre; long long soles; std::vector<std::string> paises; };
// Tarifas del ejercicio original de 2022; no son precios comerciales actuales.
inline const std::vector<Region> regiones = {
 {"America",500,{"Brasil","Argentina","Bolivia","Colombia","Uruguay","Chile","Venezuela","Peru","Ecuador","Paraguay","Estados Unidos","Canada","Mexico"}},
 {"Europa",850,{"Reino Unido","Francia","Espana","Italia","Alemania","Austria","Paises Bajos","Grecia","Polonia","Portugal","Suiza","Rusia"}},
 {"Asia",500,{"India","Vietnam","Indonesia","Taiwan","Singapur","Japon","Corea del Sur","Tailandia","Malasia","China"}},
 {"Oceania",400,{"Australia","Nueva Zelanda","Papua Nueva Guinea"}},
 {"Africa",600,{"Marruecos","Sudafrica","Tunez","Argelia","Mozambique","Zimbabue","Tanzania","Kenia","Egipto","Gambia","Nigeria"}}
};
inline const std::vector<Servicio> hoteles={{"Helios Costa Tropical",200},{"Met Hotel",322},{"Concorde De Luxe Resort",558},{"Hotel de Londres Eiffel",1013},{"Hotel Bellerive",1197}};
inline const std::vector<Servicio> restaurantes={{"Social Bar and Restaurant",250},{"Poke 51",115},{"Barra Maretazo",42},{"Resto & Lounge by Dazzlero",134},{"Paralelo Restaurante Cafe",143}};
inline const std::vector<Servicio> coches={{"BMW Series 1",250},{"Seat Leon",182},{"Nissan Juke",187},{"Toyota Aygo",210},{"Ford Mondeo",273}};
inline long long cotizar(long long tarifa,int dias) {
 if(tarifa<0 || dias<1 || dias>365) throw std::invalid_argument("Dias fuera de rango");
 return tarifa*dias;
}
