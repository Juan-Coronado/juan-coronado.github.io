import modelo.*;
import java.time.LocalDate;
import java.math.BigDecimal;
public class GestionTest {
    static Contrato contrato(int id,String inicio,String fin){return new Contrato(id,1,1,LocalDate.parse(inicio),LocalDate.parse(fin),new BigDecimal("800.00"));}
    public static void main(String[] args){
        Gestion g=new Gestion();g.agregar(new Propiedad(1,"Av. Ejemplo 123","Departamento"));
        g.agregar(new Inquilino(1,"Persona de prueba","contacto de prueba",1));
        g.agregar(contrato(1,"2026-01-01","2026-12-31"));
        boolean rechazado=false;
        try{g.agregar(contrato(2,"2026-02-01","2026-03-01"));}catch(IllegalArgumentException ex){rechazado=true;}assert rechazado;
        rechazado=false;try{g.agregar(new Inquilino(2,"X","Y",99));}catch(IllegalArgumentException ex){rechazado=true;}assert rechazado;
        g.agregar(contrato(2,"2027-01-01","2027-12-31"));
        assert g.contratos().size()==2;
        System.out.println("MVC: relaciones, duplicados de periodo y contratos consecutivos comprobados");
    }
}
