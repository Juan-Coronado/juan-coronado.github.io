import modelo.Gestion;
import vista.Vista;
import controlador.Controlador;
public class Main { public static void main(String[] args){new Controlador(new Gestion(),new Vista()).iniciar();} }
