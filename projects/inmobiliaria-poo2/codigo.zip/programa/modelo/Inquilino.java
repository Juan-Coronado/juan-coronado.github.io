package modelo;
public final class Inquilino {
    public final int id, propiedadId;
    public final String nombre, contacto;
    public Inquilino(int id,String nombre,String contacto,int propiedadId){
        if(id<1 || nombre.trim().isEmpty() || contacto.trim().isEmpty()) throw new IllegalArgumentException("Datos de inquilino incompletos");
        this.id=id;this.nombre=nombre;this.contacto=contacto;this.propiedadId=propiedadId;
    }
    public String toString(){return id+" | "+nombre+" | "+contacto+" | propiedad "+propiedadId;}
}
