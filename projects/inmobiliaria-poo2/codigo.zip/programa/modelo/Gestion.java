package modelo;
import java.util.*;
public final class Gestion {
    private final Map<Integer,Propiedad> propiedades=new LinkedHashMap<>();
    private final Map<Integer,Inquilino> inquilinos=new LinkedHashMap<>();
    private final Map<Integer,Contrato> contratos=new LinkedHashMap<>();
    public void agregar(Propiedad p){if(propiedades.containsKey(p.id))throw new IllegalArgumentException("ID de propiedad duplicado");propiedades.put(p.id,p);}
    public void agregar(Inquilino i){
        if(!propiedades.containsKey(i.propiedadId))throw new IllegalArgumentException("La propiedad no existe");
        if(inquilinos.containsKey(i.id))throw new IllegalArgumentException("ID de inquilino duplicado");
        inquilinos.put(i.id,i);
    }
    public void agregar(Contrato c){
        Inquilino i=inquilinos.get(c.inquilinoId);
        if(i==null || i.propiedadId!=c.propiedadId)throw new IllegalArgumentException("Inquilino y propiedad no corresponden");
        if(contratos.containsKey(c.id))throw new IllegalArgumentException("ID de contrato duplicado");
        for(Contrato anterior:contratos.values())
            if(anterior.propiedadId==c.propiedadId && !c.fin.isBefore(anterior.inicio) && !c.inicio.isAfter(anterior.fin))
                throw new IllegalArgumentException("La propiedad ya tiene contrato durante esas fechas");
        contratos.put(c.id,c);
    }
    public Collection<Propiedad> propiedades(){return Collections.unmodifiableCollection(propiedades.values());}
    public Collection<Inquilino> inquilinos(){return Collections.unmodifiableCollection(inquilinos.values());}
    public Collection<Contrato> contratos(){return Collections.unmodifiableCollection(contratos.values());}
}
