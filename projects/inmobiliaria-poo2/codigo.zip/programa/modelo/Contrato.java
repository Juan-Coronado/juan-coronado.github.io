package modelo;
import java.time.LocalDate;
import java.math.BigDecimal;
public final class Contrato {
    public final int id,propiedadId,inquilinoId;
    public final LocalDate inicio,fin;
    public final BigDecimal alquiler;
    public Contrato(int id,int propiedadId,int inquilinoId,LocalDate inicio,LocalDate fin,BigDecimal alquiler){
        if(id<1 || fin.isBefore(inicio) || alquiler.signum()<=0 || alquiler.scale()>2) throw new IllegalArgumentException("Revisa fechas y alquiler (positivo, maximo 2 decimales)");
        this.id=id;this.propiedadId=propiedadId;this.inquilinoId=inquilinoId;this.inicio=inicio;this.fin=fin;this.alquiler=alquiler;
    }
    public String toString(){return id+" | propiedad "+propiedadId+" | inquilino "+inquilinoId+" | "+inicio+" a "+fin+" | S/ "+alquiler;}
}
