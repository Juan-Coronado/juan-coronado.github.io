package modelo;
public final class Propiedad {
    public final int id;
    public final String direccion, tipo;
    public Propiedad(int id,String direccion,String tipo) {
        if(id<1 || direccion.trim().isEmpty() || tipo.trim().isEmpty()) throw new IllegalArgumentException("Datos de propiedad incompletos");
        this.id=id;this.direccion=direccion;this.tipo=tipo;
    }
    public String toString(){return id+" | "+direccion+" | "+tipo;}
}
