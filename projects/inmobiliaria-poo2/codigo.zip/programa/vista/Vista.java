package vista;
import java.util.Scanner;
public final class Vista {
    private final Scanner entrada=new Scanner(System.in);
    public String leer(String texto){System.out.print(texto+": ");return entrada.nextLine().trim();}
    public int entero(String texto){return Integer.parseInt(leer(texto));}
    public void mostrar(Object dato){System.out.println(dato);}
    public boolean disponible(){return entrada.hasNextLine();}
}
