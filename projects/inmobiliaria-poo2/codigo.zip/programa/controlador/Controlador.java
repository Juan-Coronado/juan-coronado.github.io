package controlador;
import modelo.*;
import vista.Vista;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.math.BigDecimal;
import java.util.NoSuchElementException;
public final class Controlador {
    private final Gestion gestion;
    private final Vista vista;
    public Controlador(Gestion gestion,Vista vista){this.gestion=gestion;this.vista=vista;}
    public void iniciar(){
        vista.mostrar("SISTEMA DE GESTION INMOBILIARIA\nVersion reconstruida desde las capturas del trabajo POO 2 (2024-I)");
        while(true){
            vista.mostrar("\n1. Agregar propiedad  2. Agregar inquilino  3. Crear contrato\n4. Propiedades  5. Inquilinos  6. Contratos  7. Salir");
            if(!vista.disponible())return;
            try {
                switch(vista.entero("Opcion")){
                    case 1:gestion.agregar(new Propiedad(vista.entero("ID"),vista.leer("Direccion"),vista.leer("Tipo")));break;
                    case 2:gestion.agregar(new Inquilino(vista.entero("ID"),vista.leer("Nombre"),vista.leer("Contacto"),vista.entero("Propiedad ID")));break;
                    case 3:gestion.agregar(new Contrato(vista.entero("ID"),vista.entero("Propiedad ID"),vista.entero("Inquilino ID"),LocalDate.parse(vista.leer("Inicio AAAA-MM-DD")),LocalDate.parse(vista.leer("Fin AAAA-MM-DD")),new BigDecimal(vista.leer("Alquiler mensual PEN"))));break;
                    case 4:gestion.propiedades().forEach(vista::mostrar);continue;
                    case 5:gestion.inquilinos().forEach(vista::mostrar);continue;
                    case 6:gestion.contratos().forEach(vista::mostrar);continue;
                    case 7:return;
                    default:vista.mostrar("Opcion fuera de rango");continue;
                }
                vista.mostrar("Registro guardado en esta sesion.");
            } catch(IllegalArgumentException | DateTimeParseException ex){vista.mostrar("Datos no validos: "+ex.getMessage());}
            catch(NoSuchElementException ex){return;}
        }
    }
}
