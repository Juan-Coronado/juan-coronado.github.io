#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <iterator>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <limits>

using namespace std;

// Estados del AEF
enum Estado {
    q0, // Recepción
    q1, // Inspección y Almacenamiento
    q2, // Procesamiento
    q3, // Empaquetado
    q4, // Despacho
    q5, // Entregado
    q10 // Rechazado
};

struct Lote {
    string nombre;
    string numero;
    string fechaRecepcion;
    string fechaVencimiento;
    Estado estadoActual = q0;
    string estatus = "Recepcion";
};

struct Excepcion {
    string descripcion;
    Estado estadoPrevio;
    string loteNumero;
};
vector<Excepcion> pila;
vector<Lote> lotes;

bool fechaValida(const string& fecha) {
    if(fecha.size()!=10 || fecha[4]!='-' || fecha[7]!='-')return false;
    tm valor={};istringstream input(fecha);input>>get_time(&valor,"%Y-%m-%d");
    if(input.fail())return false;
    int dia=valor.tm_mday,mes=valor.tm_mon,year=valor.tm_year;valor.tm_isdst=-1;
    return mktime(&valor)!=-1 && valor.tm_mday==dia && valor.tm_mon==mes && valor.tm_year==year;
}
bool registrarLote(const Lote& lote) {
    if(lote.nombre.find_first_not_of(" ")==string::npos || lote.numero.find_first_not_of(" ")==string::npos || !fechaValida(lote.fechaRecepcion) || !fechaValida(lote.fechaVencimiento) || lote.fechaVencimiento<lote.fechaRecepcion)return false;
    if(any_of(lotes.begin(),lotes.end(),[&](const Lote& l){return l.numero==lote.numero;}))return false;
    lotes.push_back(lote);return true;
}

string nombreEstado(Estado e) {
    switch (e) {
        case q0: return "Recepcion";
        case q1: return "Inspeccion y Almacenamiento";
        case q2: return "Procesamiento";
        case q3: return "Empaquetado";
        case q4: return "Despacho";
        case q5: return "Entregado";
        case q10: return "Rechazado";
        default: return "Desconocido";
    }
}

int contarExcepciones(const string& loteNumero) {
    int count = 0;
    for (const auto& ex : pila) {
        if (ex.loteNumero == loteNumero) count++;
    }
    return count;
}

void mostrarLotes() {
    if (lotes.empty()) {
        cout << "No hay lotes registrados.\n";
        return;
    }
    for (const auto& lote : lotes) {
        int exc = contarExcepciones(lote.numero);
        cout << "\n--- Lote: " << lote.numero << " ---\n";
        cout << "Mercaderia: " << lote.nombre << endl;
        cout << "Recepcion: " << lote.fechaRecepcion << endl;
        cout << "Vencimiento: " << lote.fechaVencimiento << endl;
        cout << "Estado actual: " << nombreEstado(lote.estadoActual) << endl;
        cout << "Estatus: " << lote.estatus;
        cout << " | Excepciones activas: " << exc << endl;
    }
}

void agregarExcepcion() {
    if (lotes.empty()) {
        cout << "No hay lotes registrados.\n";
        return;
    }
    string num;
    cout << "Ingrese numero de lote para la excepcion: ";
    getline(cin >> ws, num);
    for (auto& lote : lotes) {
        // Solo permitir excepciones en estados intermedios
        if (lote.numero == num) {
            if (lote.estadoActual == q0 || lote.estadoActual == q5 || lote.estadoActual == q10) {
                cout << "No se puede agregar excepcion: el lote está en Recepcion, Entregado o Rechazado.\n";
                return;
            }
            string desc;
            cout << "Descripcion de la excepcion: ";
            getline(cin, desc);
            char confirm;
            cout << "¿Esta seguro que desea registrar esta excepcion? (s/n): ";
            cin >> confirm;
            cin.ignore();
            if (confirm == 's' || confirm == 'S') {
                pila.push_back({desc, lote.estadoActual, lote.numero});
                lote.estatus = "En excepcion";
                cout << "[EXCEPCIÓN] Excepcion agregada al lote " << lote.numero << endl;
            } else {
                cout << "Accion cancelada. No se registro la excepcion.\n";
            }
            return;
        }
    }
    cout << "Lote no encontrado.\n";
}

void verPilaExcepciones() {
    if (pila.empty()) {
        cout << "No hay excepciones en la pila.\n";
        return;
    }
    cout << "--- Pila de Excepciones ---\n";
    for (const auto& ex : pila) {
        cout << "Lote: " << ex.loteNumero << " | Estado previo: " << nombreEstado(ex.estadoPrevio)
             << " | Descripcion: " << ex.descripcion << endl;
    }
}

bool tieneExcepcion(const string& loteNumero) {
    for (const auto& ex : pila) {
        if (ex.loteNumero == loteNumero) return true;
    }
    return false;
}

void resolverExcepcion(Lote& lote) {
    for (auto it = pila.rbegin(); it != pila.rend(); ++it) {
        if (it->loteNumero == lote.numero) {
            lote.estadoActual = it->estadoPrevio;
            lote.estatus = "Excepcion resuelta, proceso retomado";
            pila.erase(next(it).base());
            if(tieneExcepcion(lote.numero))lote.estatus="En excepcion";
            cout << "Excepcion resuelta y proceso retomado para el lote " << lote.numero << endl;
            return;
        }
    }
    cout << "No hay excepcion para este lote.\n";
}

void avanzarAEF(Lote& lote) {
    if (lote.estadoActual == q1) {
        int op = 0;
        while (true) {
            cout << "¿Inspeccion aprobada? (1=Si, 2=No, 3=Excepcion): ";
            if (!(cin >> op)) {
                if(cin.eof())return;
                cin.clear();
                cin.ignore(10000, '\n');
                cout << "Entrada no valida. Intente de nuevo.\n";
                continue;
            }
            if (op < 1 || op > 3) {
                cout << "Opcion fuera de rango. Intente de nuevo.\n";
                continue;
            }
            cin.ignore();
            break;
        }
        if (op == 1) {
            lote.estadoActual = q2;
            lote.estatus = "En procesamiento";
            cout << "Lote paso a Procesamiento.\n";
        } else if (op == 2) {
            lote.estadoActual = q10;
            lote.estatus = "Rechazado por inspeccion";
            cout << "Lote rechazado por inspeccion.\n";
        } else if (op == 3) {
            string desc;
            cout << "Descripcion de la excepcion: ";
            getline(cin, desc);
            char confirm;
            cout << "¿Está seguro que desea registrar esta excepcion? (s/n): ";
            cin >> confirm;
            cin.ignore();
            if (confirm == 's' || confirm == 'S') {
                pila.push_back({desc, lote.estadoActual, lote.numero});
                lote.estatus = "En excepcion";
                cout << "Excepcion apilada. Proceso detenido hasta resolver.\n";
            } else {
                cout << "Accion cancelada. No se registro la excepcion.\n";
            }
        }
    } else if (lote.estadoActual == q2) {
        lote.estadoActual = q3;
        lote.estatus = "En empaquetado";
        cout << "Lote paso a Empaquetado.\n";
    } else if (lote.estadoActual == q3) {
        lote.estadoActual = q4;
        lote.estatus = "En despacho";
        cout << "Lote paso a Despacho.\n";
    } else if (lote.estadoActual == q4) {
        lote.estadoActual = q5;
        lote.estatus = "Entregado";
        cout << "Lote entregado.\n";
    } else if (lote.estadoActual == q5) {
        cout << "El lote ya fue entregado.\n";
    } else if (lote.estadoActual == q10) {
        cout << "El lote esta rechazado. No puede avanzar.\n";
    } else {
        cout << "El lote no esta en un estado valido para avanzar.\n";
    }
}

void confirmarLlegadaLote() {
    if (lotes.empty()) {
        cout << "No hay lotes registrados.\n";
        return;
    }
    string num;
    cout << "Ingrese numero de lote para confirmar llegada: ";
    getline(cin >> ws, num);
    for (auto& lote : lotes) {
        if (lote.numero == num) {
            if (lote.estadoActual == q0) {
                char confirm;
                cout << "¿Esta seguro que desea confirmar la llegada del lote? (s/n): ";
                cin >> confirm;
                cin.ignore();
                if (confirm == 's' || confirm == 'S') {
                    lote.estadoActual = q1;
                    lote.estatus = "En inspeccion y almacenamiento";
                    cout << "Llegada confirmada. Lote paso a Inspeccion y Almacenamiento.\n";
                } else {
                    cout << "Accion cancelada. No se confirmo la llegada del lote.\n";
                }
            } else {
                cout << "El lote ya fue confirmado o está en otro estado.\n";
            }
            return;
        }
    }
    cout << "Lote no encontrado.\n";
}

int main() {
    int opcion;
    do {
        cout << "\n--- MENU PRINCIPAL ---\n";
        cout << "1. Ingresar Lote" << endl;
        cout << "2. Confirmar llegada de Lote" << endl;
        cout << "3. Mostrar Estado de Lotes" << endl;
        cout << "4. Avanzar Proceso de Lote" << endl;
        cout << "5. Agregar Excepcion" << endl;
        cout << "6. Resolver Excepcion" << endl;
        cout << "7. Ver Pila de Excepciones" << endl;
        cout << "8. Salir" << endl;
        cout << "Seleccione una opcion: ";
        string linea;char extra;
        if(!getline(cin,linea))break;
        istringstream entrada(linea);
        if(!(entrada>>opcion) || entrada>>extra){cout<<"Opcion no valida.\n";continue;}

        if (opcion == 1) {
            Lote lote;
            cout << "Nombre de la mercaderia: ";
            getline(cin, lote.nombre);
            cout << "Numero de lote: ";
            getline(cin, lote.numero);
            cout << "Fecha de recepcion: ";
            getline(cin, lote.fechaRecepcion);
            cout << "Fecha de vencimiento: ";
            getline(cin, lote.fechaVencimiento);
            lote.estadoActual = q0;
            lote.estatus = "Recepcion";
            if(registrarLote(lote))cout<<"Lote registrado en Recepcion.\n";
            else cout<<"Datos invalidos: revisa fechas AAAA-MM-DD, nombre y numero unico.\n";
        }
        else if (opcion == 2) {
            confirmarLlegadaLote();
        }
        else if (opcion == 3) {
            mostrarLotes();
        }
        else if (opcion == 4) {
            string num;
            cout << "Ingrese numero de lote para avanzar: ";
            getline(cin >> ws, num);
            for (auto& lote : lotes) {
                if (lote.numero == num) {
                    if (tieneExcepcion(lote.numero)) {
                        cout << "El lote tiene una excepcion pendiente. Resuelvala antes de avanzar.\n";
                    } else {
                        avanzarAEF(lote);
                    }
                    break;
                }
            }
        }
        else if (opcion == 5) {
            agregarExcepcion();
        }
        else if (opcion == 6) {
            string num;
            cout << "Ingrese numero de lote para resolver excepcion: ";
            getline(cin >> ws, num);
            for (auto& lote : lotes) {
                if (lote.numero == num) {
                    resolverExcepcion(lote);
                    break;
                }
            }
        }
        else if (opcion == 7) {
            verPilaExcepciones();
        }
        else if (opcion == 8) {
            cout << "Saliendo del sistema...\n";
        }
        else {
            cout << "Opcion no valida.\n";
        }
    } while (opcion != 8);  
    return 0;
}   