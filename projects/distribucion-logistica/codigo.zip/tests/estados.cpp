#define main programa_main
#include "../programa/Codigo - Trabajo Final Grupo 5 (1).cpp"
#undef main
#include <cassert>
int main(){
    Lote lote{"Producto de prueba","L001","2026-10-19","2026-10-25",q0,"Recepcion"};
    assert(registrarLote(lote));assert(!registrarLote(lote));
    Lote malo=lote;malo.numero="L002";malo.fechaRecepcion="2026-02-31";assert(!registrarLote(malo));
    lotes[0].estadoActual=q1;
    pila.push_back({"Incidencia uno",q1,"L001"});pila.push_back({"Incidencia dos",q1,"L001"});
    resolverExcepcion(lotes[0]);assert(tieneExcepcion("L001") && lotes[0].estatus=="En excepcion");
    resolverExcepcion(lotes[0]);assert(!tieneExcepcion("L001") && lotes[0].estadoActual==q1);
    std::istringstream aprobacion("1\n");auto* anterior=cin.rdbuf(aprobacion.rdbuf());
    avanzarAEF(lotes[0]);cin.rdbuf(anterior);assert(lotes[0].estadoActual==q2);
    avanzarAEF(lotes[0]);avanzarAEF(lotes[0]);avanzarAEF(lotes[0]);assert(lotes[0].estadoActual==q5);
    avanzarAEF(lotes[0]);assert(lotes[0].estadoActual==q5);
    lotes[0].estadoActual=q1;std::istringstream rechazo("2\n");anterior=cin.rdbuf(rechazo.rdbuf());
    avanzarAEF(lotes[0]);cin.rdbuf(anterior);assert(lotes[0].estadoActual==q10);
}
