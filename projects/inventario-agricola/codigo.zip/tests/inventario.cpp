#include "../programa/inventario.hpp"
#include <cassert>
int main(){
    Inventario original;original.agregar("Manzana roja","Fruta","2026-10-19",12);
    original.guardar("prueba.txt");Inventario copia;copia.cargar("prueba.txt");
    assert(copia.primero()->nombre=="Manzana roja");
    copia.agregar("Zanahoria","Verdura","2026-10-19",7);copia.guardar("prueba.txt");
    original.cargar("prueba.txt");assert(original.primero()->siguiente!=nullptr);
    std::ofstream("roto.txt")<<"Producto incompleto\n";
    bool fallo=false;try{original.cargar("roto.txt");}catch(const std::runtime_error&){fallo=true;}
    assert(fallo && original.primero()->nombre=="Zanahoria");
    assert(!fechaValida("2026-02-31") && fechaValida("2024-02-29"));
}
