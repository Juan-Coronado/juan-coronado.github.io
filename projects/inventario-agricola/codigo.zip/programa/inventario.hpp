#pragma once
#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <filesystem>
#include <iomanip>
#include <ctime>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif
struct Producto {
    std::string nombre,tipo,fecha_ingreso;
    int tiempo_vida;
    Producto* siguiente=nullptr;
};
inline bool fechaValida(const std::string& fecha){
    if(fecha.size()!=10 || fecha[4]!='-' || fecha[7]!='-')return false;
    std::tm tm={};std::istringstream in(fecha);in>>std::get_time(&tm,"%Y-%m-%d");
    if(in.fail())return false;
    const int dia=tm.tm_mday,mes=tm.tm_mon,year=tm.tm_year;tm.tm_isdst=-1;
    return std::mktime(&tm)!=-1 && tm.tm_mday==dia && tm.tm_mon==mes && tm.tm_year==year;
}
class Inventario {
    Producto* cabeza=nullptr;
public:
    Inventario()=default;
    Inventario(const Inventario&)=delete;
    Inventario& operator=(const Inventario&)=delete;
    ~Inventario(){while(cabeza){auto* anterior=cabeza;cabeza=cabeza->siguiente;delete anterior;}}
    const Producto* primero()const{return cabeza;}
    void agregar(std::string nombre,std::string tipo,std::string fecha,int vida){
        if(nombre.empty() || nombre.size()>100 || nombre.find_first_not_of(" \t")==std::string::npos || nombre.find_first_of("\r\n")!=std::string::npos || (tipo!="Fruta" && tipo!="Verdura") || !fechaValida(fecha) || vida<1 || vida>3650)
            throw std::invalid_argument("Revisa nombre, tipo (Fruta/Verdura), fecha y vida (1-3650 dias)");
        cabeza=new Producto{nombre,tipo,fecha,vida,cabeza};
    }
    void cargar(const std::filesystem::path& path){
        if(!std::filesystem::exists(path))return;
        std::ifstream in(path);if(!in)throw std::runtime_error("No se pudo leer el archivo");
        Inventario temporal;Producto** ultimo=&temporal.cabeza;
        std::string nombre,tipo,fecha,vida;
        while(std::getline(in,nombre)){
            if(!std::getline(in,tipo) || !std::getline(in,fecha) || !std::getline(in,vida))throw std::runtime_error("Archivo incompleto; no se modifica el inventario");
            int dias;char resto;std::istringstream num(vida);
            if(!(num>>dias) || num>>resto)throw std::runtime_error("Vida del producto no valida");
            Inventario valido;valido.agregar(nombre,tipo,fecha,dias);
            auto* item=valido.cabeza;valido.cabeza=nullptr;*ultimo=item;ultimo=&item->siguiente;
        }
        if(!in.eof())throw std::runtime_error("Error al leer el inventario");
        std::swap(cabeza,temporal.cabeza);
    }
    void guardar(const std::filesystem::path& path)const{
        auto tmp=path;tmp+=".tmp";
        try {
            std::ofstream out(tmp,std::ios::trunc);if(!out)throw std::runtime_error("No se pudo crear el archivo temporal");
            for(auto* p=cabeza;p;p=p->siguiente)out<<p->nombre<<'\n'<<p->tipo<<'\n'<<p->fecha_ingreso<<'\n'<<p->tiempo_vida<<'\n';
            out.close();if(!out)throw std::runtime_error("Error de escritura; se conserva el archivo anterior");
#ifdef _WIN32
            if(!MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))throw std::runtime_error("No se pudo reemplazar el inventario anterior");
#else
            std::filesystem::rename(tmp,path);
#endif
        } catch(...){std::error_code error;std::filesystem::remove(tmp,error);throw;}
    }
};
