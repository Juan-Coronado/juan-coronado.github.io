#include "inventario.hpp"
#include <iostream>
#include <limits>
std::string hoy(){std::time_t t=std::time(nullptr);std::tm tm={};
#ifdef _WIN32
 localtime_s(&tm,&t);
#else
 tm=*std::localtime(&t);
#endif
 std::ostringstream out;out<<std::put_time(&tm,"%Y-%m-%d");return out.str();}
int main(){
 Inventario inventario;
 try{inventario.cargar("productos.txt");}catch(const std::exception& e){std::cerr<<e.what()<<"\nArchivo conservado sin cambios.\n";return 1;}
 std::string linea;
 while(std::cout<<"\nINVENTARIO AGRICOLA\n1. Registrar  2. Listar  3. Guardar  4. Salir\nOpcion: " && std::getline(std::cin,linea)){
  if(linea=="4")break;
  try{
   if(linea=="1"){
    std::string nombre,tipo,vida;int dias;char resto;
    std::cout<<"Nombre: ";if(!std::getline(std::cin,nombre))break;
    std::cout<<"Tipo (Fruta/Verdura): ";if(!std::getline(std::cin,tipo))break;
    std::cout<<"Vida en dias: ";if(!std::getline(std::cin,vida))break;
    std::istringstream numero(vida);if(!(numero>>dias) || numero>>resto)throw std::invalid_argument("Vida no valida");
    inventario.agregar(nombre,tipo,hoy(),dias);std::cout<<"Producto registrado. Usa Guardar para conservarlo.\n";
   }else if(linea=="2"){
    if(!inventario.primero())std::cout<<"No hay productos registrados.\n";
    for(auto* p=inventario.primero();p;p=p->siguiente)std::cout<<p->nombre<<" | "<<p->tipo<<" | ingreso "<<p->fecha_ingreso<<" | vida "<<p->tiempo_vida<<" dias\n";
   }else if(linea=="3"){inventario.guardar("productos.txt");std::cout<<"Productos guardados.\n";}
   else std::cout<<"Opcion no valida.\n";
  }catch(const std::exception& e){std::cout<<e.what()<<'\n';}
 }
 std::cout<<"Sesion finalizada.\n";
}
