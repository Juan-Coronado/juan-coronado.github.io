/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.programapaquete;

/**
 *
 * @author USUARIO
 */
public class ProgramaPaquete {

    public static void main(String[] args) 
    {
        AplicacionPractica aplicacionPractica = new AplicacionPractica();
        aplicacionPractica.setVisible(true);
    }
}
