/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.programapaquete;

/**
 *
 * @author USUARIO
 */
public class Aplicacion 
{
    private String Nombre;
    private String Apellido;
    private String Telefono;
    private String DNI;
    private int Personas;
    private String Aerolinea;
    private String Destino;
    private String Hotel;
    private String Origen;
    private int Dias;

    public Aplicacion(String Nombre, String Apellido, String Telefono, String DNI, int Personas, String Aerolinea, String Destino, String Hotel, String Origen, int Dias) {
        for (String valor : new String[]{Nombre, Apellido, Telefono, DNI, Aerolinea, Destino, Hotel, Origen})
            if (valor == null || valor.trim().isEmpty()) throw new IllegalArgumentException("Completa todos los campos");
        if (!DNI.matches("[0-9]{8}")) throw new IllegalArgumentException("El DNI debe tener 8 digitos");
        if (!Telefono.matches("[+0-9 ()-]{7,20}")) throw new IllegalArgumentException("Telefono no valido");
        if (Personas < 1 || Personas > 100 || Dias < 1 || Dias > 365) throw new IllegalArgumentException("Personas: 1-100. Dias: 1-365");
        //Constructor
        
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Telefono = Telefono;
        this.DNI = DNI;
        this.Personas = Personas;
        this.Aerolinea = Aerolinea;
        this.Destino = Destino;
        this.Hotel = Hotel;
        this.Origen = Origen;
        this.Dias = Dias;
    }
    
    

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public int getPersonas() {
        return Personas;
    }

    public void setPersonas(int Personas) {
        this.Personas = Personas;
    }

    public String getAerolinea() {
        return Aerolinea;
    }

    public void setAerolinea(String Aerolinea) {
        this.Aerolinea = Aerolinea;
    }

    public String getDestino() {
        return Destino;
    }

    public void setDestino(String Destino) {
        this.Destino = Destino;
    }

    public String getHotel() {
        return Hotel;
    }

    public void setHotel(String Hotel) {
        this.Hotel = Hotel;
    }

    public String getOrigen() {
        return Origen;
    }

    public void setOrigen(String Origen) {
        this.Origen = Origen;
    }

    public int getDias() {
        return Dias;
    }

    public void setDias(int Dias) {
        this.Dias = Dias;
    }

    @Override
    public String toString() {
        
        //Generamos cadena de texto
        return Nombre + " " + Apellido + " | " + Origen + " -> " + Destino
               + " | Hotel: " + Hotel + " | " + Personas + " personas | " + Dias + " dias";
    }
    
    
    
}
