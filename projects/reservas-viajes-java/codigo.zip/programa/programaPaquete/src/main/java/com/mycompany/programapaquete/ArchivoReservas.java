package com.mycompany.programapaquete;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Collectors;

public final class ArchivoReservas {
    private ArchivoReservas() {}
    public static void guardar(Path destino, List<Aplicacion> reservas) throws IOException {
        if (reservas.isEmpty()) throw new IllegalArgumentException("No hay reservas");
        Path archivo = destino.toAbsolutePath();
        Path temporal = Files.createTempFile(archivo.getParent(), "reservas-", ".tmp");
        try {
            Files.write(temporal, reservas.stream().map(Aplicacion::toString).collect(Collectors.toList()), StandardCharsets.UTF_8);
            try { Files.move(temporal, archivo, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temporal); }
    }
}
