package com.mycompany.programapaquete;
import javax.swing.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.util.List;

public class ReservasTest {
    static Object field(Object frame,String name) throws Exception {
        Field field=frame.getClass().getDeclaredField(name);field.setAccessible(true);return field.get(frame);
    }
    public static void main(String[] args) throws Exception {
        Aplicacion reserva=new Aplicacion("Juan","Coronado","999000000","00000000",2,"Academica","Cusco","Hotel Ejemplo","Lima",3);
        assert reserva.getOrigen().equals("Lima") && reserva.getHotel().equals("Hotel Ejemplo");
        boolean fallo=false;
        try { new Aplicacion("","A","999000000","00000000",2,"A","B","C","D",3); } catch (IllegalArgumentException ex) { fallo=true; }
        assert fallo;
        Path reporte=Files.createTempFile("reserva-test", ".txt");
        ArchivoReservas.guardar(reporte,List.of(reserva));
        assert Files.readString(reporte).contains("Lima -> Cusco");Files.delete(reporte);
        SwingUtilities.invokeAndWait(() -> {
            AplicacionPractica frame=new AplicacionPractica();
            try {
                String[][] campos={{"txtNombres","Juan Antonio"},{"txtApellidos","Coronado Palacios"},{"txtTelefono","999000000"},{"txtDNI","00000000"},{"txtPersonas","2"},{"txtDias","3"},{"txtAerolinea","Academica"},{"txtDestino","Cusco"},{"txtOrigen","Lima"},{"txtHotel","Hotel Ejemplo"}};
                for(String[] par:campos)((JTextField)field(frame,par[0])).setText(par[1]);
                ((JButton)field(frame,"btnGenerar")).doClick();
                JList<?> lista=(JList<?>)field(frame,"LstAplicacion");
                assert lista.getModel().getSize()==1;
                assert lista.getModel().getElementAt(0).toString().contains("Lima -> Cusco");
                ((JTextField)field(frame,"txtDestino")).setText("Arequipa");
                ((JButton)field(frame,"btnGenerar")).doClick();
                assert lista.getModel().getSize()==2;
                assert !lista.getModel().getElementAt(0).equals(lista.getModel().getElementAt(1));
                java.awt.Container contenido=frame.getContentPane();
                contenido.doLayout();
                BufferedImage image=new BufferedImage(contenido.getWidth(),contenido.getHeight(),BufferedImage.TYPE_INT_RGB);
                java.awt.Graphics2D graphics=image.createGraphics();
                contenido.printAll(graphics);graphics.dispose();
                java.util.Set<Integer> colores=new java.util.HashSet<>();
                for(int y=0;y<image.getHeight();y+=10)for(int x=0;x<image.getWidth();x+=10)colores.add(image.getRGB(x,y));
                assert colores.size()>5 : "La captura de Swing debe contener la interfaz, no un lienzo vacio";
                ImageIO.write(image,"png",Path.of(args[0]).toFile());
            } catch(Exception ex) { throw new RuntimeException(ex); }
            finally { frame.dispose(); }
        });
        System.out.println("Reservas: modelo, validacion, guardado atomico, dos filas diferentes y render Swing correctos");
    }
}
